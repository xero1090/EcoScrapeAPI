//
//  Kevin_WeatherApp.swift
//  Kevin_Weather
//
//  Created by Kevin Tran on 2021-11-12.
//

import SwiftUI

@main
struct Kevin_WeatherApp: App {
    let persistenceController = PersistenceController.shared
    let locationHelper = LocationHelper()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
                .environmentObject(locationHelper)
        }
    }
}
