//
//  ForwardGeoView.swift
//  Kevin_Weather
//
//  Created by Kevin Tran on 2021-11-13.
//

import Foundation
import SwiftUI
import CoreLocation

struct ForwardGeoView: View {
    @State private var tfStreet : String = ""
    @State private var tfCity : String = ""
    @State private var tfCountry : String = ""
    @State private var result : String = ""
    @EnvironmentObject var locationHelper : LocationHelper
    @State private var obtainedCoordinates : CLLocation?
    
    var body: some View {
        VStack{
            Text("Forward Geocoding")
                .foregroundColor(.red)
                .fontWeight(.bold)
                .font(.system(size: 30))
                .padding()
            
            Form{
                TextField("Enter Street", text: $tfStreet)
                    .modifier(AppTextFieldModifier())
                
                TextField("Enter City", text: $tfCity)
                    .modifier(AppTextFieldModifier())
                
                TextField("Enter Country", text: $tfCountry)
                    .modifier(AppTextFieldModifier())
            }//Form
            
            Text("\(self.result)")
                .foregroundColor(.red)
                .fontWeight(.bold)
                .font(.system(size: 30))
                .padding()
            
            
            Button(action: {
                let address = "\(self.tfStreet), \(self.tfCity), \(self.tfCountry)"
                self.doGeocoding(address: address)
            }){
                Text("Forward Geocoding")
                    .modifier(AppButtonTextModifier())
            }
            .modifier(AppButtonModifier())
            
            Spacer()
        }//VStack
    }//body
    
    private func doGeocoding(address: String){
        self.locationHelper.doGeocoding(address: address, completionHandler: { (coordinates, error) in
            
            if (error == nil && coordinates != nil){
                //sucessfully obtained coordinates
                self.obtainedCoordinates = coordinates!
                result = "Lat: \(coordinates!.coordinate.latitude) \n Lng: \(coordinates!.coordinate.longitude)"
                
                print(#function, "Coordinates obtained : Lat: \(coordinates!.coordinate.latitude) \n Lng: \(coordinates!.coordinate.longitude)")
            }else{
                result = "Unable to get coordinates for given address"
                //prompt the user of unavailable address or route
                print(#function, "error: ", error?.localizedDescription as Any)
            }
        })
    }
}

struct ForwardGeoView_Previews: PreviewProvider {
    static var previews: some View {
        ForwardGeoView()
    }
}
