//
//  ForecastView.swift
//  Kevin_Weather
//
//  Created by Kevin Tran on 2021-11-14.
//
import CoreLocation
import SwiftUI

struct ForecastView: View {
    @State private var location: String=""
    @State private var forecast: Forecast? = nil
    var body: some View {
        NavigationView{
        VStack{
            HStack{
                TextField("Enter Your Location", text: $location)
                Button{
                    getForecast(for: location)
                }label: {
                    Image(systemName: "magnifyingglass.circle.fill")
                }
            }
            /*List View for the data (If it would display >:L )
            if let forecast = forecast?.daily {
                List(forecast.location.tz_id, id: \.tz_id){ day in
                    Text("\(day.tz_id)")
                }
            }else{
                Spacer()
            }*/
        }
        .padding(.horizontal)
        .navigationTitle("Mobile Weather")
    }
    }
        
    func getForecast(for location: String){
        
        let apiService = APIService.shared
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E, MMM, d"
        CLGeocoder().geocodeAddressString(location){(placemarks,error) in
            if let error = error{
                print(error.localizedDescription)
            }
            if let lat = placemarks?.first?.location?.coordinate.latitude,
               let lon = placemarks?.first?.location?.coordinate.longitude{
        apiService.getJSON(urlString: "http://api.weatherapi.com/v1/current.json?key=5754252c81c84e9a930212757211211&q=\(lat),\(lon)&aqi=no") { (result: Result<Forecast,APIService.APIError>) in
            switch result {
            case .success(let forecast):
                self.forecast = forecast
                /*for day in forecast.daily {
                    print(dateFormatter.string(from: day.location.localtime_epoch))
                    print("     Region: ", day.location.region)
                    print("     Country: ", day.location.country)
                    print("     Temp: ", day.current.temp_c)
                    print("     Feels Like: ", day.current.feelslike_c)
                    print("     Wind Kph: ", day.current.wind_kph)
                    print("     Wind direction: ", day.current.wind_dir)
                    print("     Humidity: ", day.current.humidity)
                    print("     Ultra Violet: ", day.current.uv)
                    print("     Visibilty Km: ", day.current.vis_km)
                    
                }*/
            case .failure(let apiError):
                switch apiError{
                case .error(let errorString):
                    print(errorString)
                }
            }
        }
            }
        }

    }
}

struct ForecastView_Previews: PreviewProvider {
    static var previews: some View {
        ForecastView()
    }
}
