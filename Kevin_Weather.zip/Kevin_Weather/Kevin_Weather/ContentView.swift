//
//  ContentView.swift
//  Kevin_Weather
//
//  Created by Kevin Tran on 2021-11-12.
//

import SwiftUI
import CoreData

struct ContentView: View {
    var body: some View {
        TabView{
            MapView().tabItem{
                Image(systemName: "map.fill")
                Text("Map")
            }
            ForecastView().tabItem{
                Image(systemName: "map")
                Text("Forecast")
            }
            
            
        }.navigationBarTitle("LocationDemo")
        
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
