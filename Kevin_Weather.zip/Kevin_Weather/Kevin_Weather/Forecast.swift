//
//  Forecast.swift
//  Kevin_Weather
//
//  Created by Kevin Tran on 2021-11-14.
//

import Foundation
struct Forecast: Codable{
    struct Daily: Codable{
    struct Location: Codable{
        let name: String
        let region: String
        let country: String
        let lat: Double
        let lon: Double
        let tz_id: String
        let localtime_epoch: Date
    }
    let location: Location
    struct Current: Codable{
        let temp_c: Double
        let feelslike_c: Double
        let wind_kph: Double
        let wind_dir: String
        let humidity: Int
        let uv: Double
        let vis_km: Double
        struct Condition: Codable{
            let text: String
            let icon: String
            let code: Int
            var weatherIconURL: URL {
                let urlString = "//cdn.weatherapi.com/weather/64x64/day/\(icon).png"
                return URL(string: urlString)!
            }
        }
        let condition: [Condition]
    }
    let current: Current
    }; let daily: [Daily]
    
}
