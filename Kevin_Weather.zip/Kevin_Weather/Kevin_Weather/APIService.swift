//
//  APIService.swift
//  Kevin_Weather
//
//  Created by Kevin Tran on 2021-11-14.
//

import Foundation

class APIService{
    static let shared = APIService()
    
    enum APIError: Error{
        case error(_ errorString: String)
    }
    
    func getJSON(urlString: String, completion: @escaping(Result<Forecast,APIError>)-> Void){
        guard let url = URL(string: urlString) else {
            completion(.failure(.error("Error: Invalid URL")))
            return
        }
        let request = URLRequest(url: url)
        URLSession.shared.dataTask(with: request){ (data, response, error) in
            if let error = error {
                completion(.failure(.error("Error: \(error.localizedDescription)")))
                return
            }
            guard let data = data else {
                completion(.failure(.error("Error: Data is corrupt.")))
                return
            }
            let decoder = JSONDecoder()
            do{
                let decodedData = try decoder.decode(Forecast.self, from: data)
                completion(.success(decodedData))
                return
            } catch let decodingError {
                completion(.failure(APIError.error("Error: \(decodingError.localizedDescription)")))
            }
            
        }.resume()
    }
}
